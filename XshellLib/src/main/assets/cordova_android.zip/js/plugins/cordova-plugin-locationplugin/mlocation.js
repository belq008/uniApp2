cordova.define("cordova-plugin-locationplugin.mlocation", function(require, exports, module) {

var exec = require('cordova/exec');

module.exports = {
    
    location: function(callBackName) {
        exec(null, null, "LocationPlugin", "location", [{"callBackName":callBackName}]);
    }
};

});
