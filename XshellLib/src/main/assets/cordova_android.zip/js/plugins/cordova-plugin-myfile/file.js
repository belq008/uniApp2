cordova.define("cordova-plugin-myfile.file", function(require, exports, module) { 


var exec = require('cordova/exec');

/**
 * Provides access to notifications on the device.
 */

module.exports = {
    //读取文件
	readFile : function(filePath, successCallBack, failureCallBack) {
        exec(successCallBack, failureCallBack, "FileOperationPlugin", "readFile", [filePath]);
    },
	//写入文件
	writeFile : function(filePath, data, append, failureCallBack) {
	    var mAppend;
		if (arguments.length == 3) {
         	mAppend = false;
         	failureCallBack = append;
        } else {
         	mAppend = append;
       }
		exec(null, failureCallBack, "FileOperationPlugin", "writeFile", [filePath, data, mAppend]);
	},
	//判断文件是否存在
	exist : function(filePath, successCallBack) {
		exec(successCallBack, null, "FileOperationPlugin", "exist", [filePath]);
	},
	//删除文件
	deleteFile : function(filePath, failureCallBack) {
		exec(null, failureCallBack, "FileOperationPlugin", "deleteFile", [filePath]);
	},
	//浏览文件
	openFile : function(filePath) {
		exec(null, null, "FileOperationPlugin", "openFile", [filePath]);
	}
};

});
