cordova.define("cordova-plugin-screenLandscape.screenLandscape.js", function(require, exports, module) {

var exec = require('cordova/exec');

/**
 * Provides access to notifications on the device.
 */
module.exports = {
    
    screenLandscape: function(callback,type) {
        exec(
        		null,
        		null,
        		'screenLandscapePlugin',
        		'startToChangeOrientation',
        		[{'type':type,'callbackName':callback}]
        	);
    }
};

});
