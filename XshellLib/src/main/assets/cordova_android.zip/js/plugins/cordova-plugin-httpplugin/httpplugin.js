cordova.define("cordova-plugin-httpplugin", function(require, exports,
		module) {

	var exec = require('cordova/exec');
	module.exports = {
		//开始视频播放
		request : function(id) {
			exec(null, null, "CordovaHttpPlugin", "post", [ url,params,headers ]);
		}
	};

});
