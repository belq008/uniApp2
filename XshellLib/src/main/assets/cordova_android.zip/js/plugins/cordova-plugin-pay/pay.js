cordova.define("cordova-plugin-pay.pay", function(require, exports, module) { 


var exec = require('cordova/exec');

/**
 * Provides access to notifications on the device.
 */

module.exports = {
    //支付宝支付
	alipay : function(orderString, successCallBack, failureCallBack) {
        exec(successCallBack, failureCallBack, "AlipayPlugin", "alipay", [orderString]);
    },
	//微信支付
	wxpay : function(payInfo, successCallBack, failureCallBack) {
		exec(successCallBack, failureCallBack, "WeChatPlugin", "wxpay", [payInfo]);
	}
};

});
