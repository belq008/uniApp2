cordova.define("cordova-plugin-showKeyboard.showkeyboard.js", function(require, exports, module) {

var exec = require('cordova/exec');

/**
 * Provides access to notifications on the device.
 */
module.exports = {
    
    screenLandscape: function(callback,type) {
        	exec(
        		null,
        		null,
        		'showKeyBoardPlugin',
        		'showkeyboard',
        		[callBackName,type,defultKeyboard]
        	);
    }

};

});
