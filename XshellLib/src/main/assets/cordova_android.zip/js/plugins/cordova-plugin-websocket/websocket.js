cordova.define("cordova-plugin-websocket.websocket", function(require, exports,module) {

	var exec = require('cordova/exec');

	module.exports = {
		//连接WebSocket
		open : function(url, successCallBack, failureCallBack) {
			exec(successCallBack, failureCallBack, "WebSocketPlugin", "open", [url]);
		},
		//关闭WebSocket
		close : function(successCallBack, failureCallBack) {
			exec(successCallBack, failureCallBack, "WebSocketPlugin", "close", []);
		},
		//WebSocket是否连接
		isConnect : function(successCallBack) {
			exec(successCallBack, null, "WebSocketPlugin", "isConnect", []);
		},
		//发送请求
		sendMessage : function(command, param, successCallBack, failureCallBack) {
			exec(successCallBack, failureCallBack, "WebSocketPlugin", "sendMessage", [command, param]);
		},
		//注册通道
		registerPush : function(command, param, successCallBack, failureCallBack) {
			exec(successCallBack, failureCallBack, "WebSocketPlugin", "registerPush", [command, param]);
		},
		//订阅推送
		subscribePush : function(command, param, successCallBack, failureCallBack) {
			exec(successCallBack, failureCallBack, "WebSocketPlugin", "subscribePush", [command, param]);
		},
		//取消订阅
		unSubscribePush : function(command, param, successCallBack, failureCallBack) {
			exec(successCallBack, failureCallBack, "WebSocketPlugin", "unSubscribePush", [command, param]);
		}
	};

});
