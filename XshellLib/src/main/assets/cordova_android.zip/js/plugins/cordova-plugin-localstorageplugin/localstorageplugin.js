cordova.define("cordova-plugin-localstorageplugin.localstorageplugin", function(require, exports,
		module) {

	var exec = require('cordova/exec');
	module.exports = {
       
        //存储key-value数据
        setValue : function (key, value) {
            exec(null, null, "LocalstoragePlugin", "setValue", [key, value]);
        },
        //通过key取相应的数据
        getByKey : function (key, successCallBack, failedCallBack) {
            exec(successCallBack, failedCallBack, "LocalstoragePlugin", "getByKey", [key]);
        },
        //存储List数据
        setList : function (key, idArr, list) {
            exec(null, null, "LocalstoragePlugin", "setList", [key, idArr, list]);
        },
        //更新某条数据
        updateData : function (key, id, value) {
            exec(null, null, "LocalstoragePlugin", "updateData", [key, id, value]);
        },
        //删除某条数据
        deleteDataByKeyID : function (key, id) {
            exec(null, null, "LocalstoragePlugin", "deleteDataByKeyID", [key, id]);
        },
        //删除某些数据
        deleteDataByKeySomeID : function (key, idStr) {
            exec(null, null, "LocalstoragePlugin", "deleteDataByKeySomeID", [key, idStr]);
        },
        //删除key对应的所有数据
        deleteDataByKey : function (key) {
            exec(null, null, "LocalstoragePlugin", "deleteDataByKey", [key]);
        },
        //获取某条数据
        getDataByKeyID : function (key, id, successCallBack, failedCallBack) {
            exec(successCallBack, failedCallBack, "LocalstoragePlugin", "getDataByKeyID", [key, id]);
        },
        //获取key对应的所有数据
        getAllData : function (key, successCallBack, failedCallBack) {
            exec(successCallBack, failedCallBack, "LocalstoragePlugin", "getAllData", [key]);
        },
        //根据一定的顺序获取所有的数据
        getAllDataByKey : function (key, sort, successCallBack, failedCallBack) {
            var sortStr;
            if (sort == undefined || sort == null) {
                sortStr = "asc";
            } else {
                sortStr = sort;
            }
            exec(successCallBack, failedCallBack, "LocalstoragePlugin", "getAllDataByKey", [key, sortStr]);
        },
        //获取Num条数据
        getNumDataByKey : function (key, num, sort, successCallBack, failedCallBack) {
            var sortStr;
            if (sort == undefined || sort == null) {
                sortStr = "asc";
            } else {
                sortStr = sort;
            }
            exec(successCallBack, failedCallBack, "LocalstoragePlugin", "getNumDataByKey", [key, num, sortStr]);
        },
        //获取某条id前/后N条数据，默认向前查询
        getNumDataByKeyID : function (key, id, num, direction, successCallBack, failedCallBack) {
            var fangxiang;
            if (direction == undefined || direction == null) {
                fangxiang = "before";
            } else {
                fangxiang = direction;
            }
            exec(successCallBack, failedCallBack, "LocalstoragePlugin", "getNumDataByKeyID", [key, id, num, fangxiang]);
        },
        //获取一些id的数据
        getDataByKeyAndSomeID : function (key, idStr, successCallBack, failedCallBack) {
            exec(successCallBack, failedCallBack, "LocalstoragePlugin", "getDataByKeyAndSomeID", [key, idStr]);
        },
        //记录XLog
        recordLog : function (jsonStr) {
            exec(null, null, "XLogPlugin", "recordLog", [jsonStr]);
        },
        //用户行为记录
        userrecord : function (record) {
            exec(null, null, "XLogPlugin", "userrecord", [record]);
        },
	};

});
