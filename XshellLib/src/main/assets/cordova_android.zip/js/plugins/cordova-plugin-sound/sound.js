cordova.define("cordova-plugin-sound.sound.js", function(require, exports, module) {

var exec = require('cordova/exec');

/**
 * Provides access to notifications on the device.
 */
module.exports = {
    
    screenLandscape: function(callback,type) {
        	exec(
            		successCallback,
            		errorCallback,
            		'SoundPlugin',
            		'sound',
            		[{'soundfilename':filename}]
            	);
    }
};

});
