cordova.define("cordova-plugin-uniapp.uniapp", function(require, exports,
		module) {

	var exec = require('cordova/exec');
	module.exports = {
        //打开新窗口
        openWindow : function (url, effict, successCallBack) {
            var type;
            if (arguments.length == 2) {
                type = -1;
                successCallBack = effict;
            } else {
                type = effict;
            }
            exec(successCallBack, null, "NativePlugin", "openWindow", [url, type]);
        },
        //关闭新窗口
        closeWindow : function (param) {
            var obj;
            if (arguments.length == 0) {
                obj = {'animate' : true};
            } else {
                if (param.animate == undefined || param.animate == null) {
                    obj = {'animate' : true, 'value' : param.value};
                } else {
                    obj = param;
                }
            }
            exec(null, null, "NativePlugin", "closeWindow", [obj]);
        },
        //输入框弹框
        commentbox : function (object, successCallBack) {
            exec(successCallBack, null, "CommentBoxPlugin", "commentbox", [object]);
        },
        //复制文本到粘贴板
        clipboard : function (text) {
            exec(null, null, "NativePlugin", "clipboard", [text]);
        },
       
        //图片浏览器
        pictureBrowser : function (param, url) {
            exec(null, null, "PictureBrowserPlugin", "pictureBrowser", [param, url]);
        },
        getWebInfo : function (successCallBack) {
                exec(successCallBack, null, "AppNativePlugin", "getWebInfo", []);
         },
	    appStatus  : function (successCallBack) {
                exec(successCallBack, null, "AppNativePlugin", "appStatus", []);
         },    
		speechStart : function (param, successCallBack) {
            exec(successCallBack, null, "AppNativePlugin", "speechStart", [param]);
        },
	    addCalendar : function (param, successCallBack) {
            exec(successCallBack, null, "AppNativePlugin", "addCalendar", [param]);
        },
	    deletCalendar : function (param, successCallBack) {
            exec(successCallBack, null, "AppNativePlugin", "deletCalendar", [param]);
        },
	    getCalendar : function (successCallBack) {
            exec(successCallBack, null, "AppNativePlugin", "getCalendar", []);
        }
		
	};

});
