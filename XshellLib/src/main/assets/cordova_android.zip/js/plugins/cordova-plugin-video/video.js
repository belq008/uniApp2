cordova.define("cordova-plugin-video.video", function(require, exports, module) { 


var exec = require('cordova/exec');

/**
 * Provides access to notifications on the device.
 */

module.exports = {
    //视屏直播或者回放
	livePlay : function(playUrl, videoType, filePath, successCallBack) {
        exec(successCallBack, null, "LiveVideoPlugin", "livePlay", [playUrl, videoType, filePath]);
    }
};

});
