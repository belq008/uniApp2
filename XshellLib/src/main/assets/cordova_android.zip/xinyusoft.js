var NativePlugin = function(){};

NativePlugin.prototype.createWindow = function(url, id, title) {
	cordova.exec(
		null,
		null,
		'NativePlugin',
		'createWindow',
		[{'url' : url, 'windowid' : id, 'title' : title}]
	);
}

NativePlugin.prototype.createNotFullWindow = function(url, id, title, width, height) {
	cordova.exec(
		null,
		null,
		'NativePlugin',
		'createNotFullWindow',
		[{'url' : url, 'windowid' : id, 'title' : title, 'width' : width, 'height' : height}]
	);
}

if(!window.plugins){
	window.plugins = {};
}
if(!window.plugins.NativePlugin){
	window.plugins.NativePlugin = new NativePlugin();
	for(var key in window.plugins.NativePlugin){
		window[key] = window.plugins.NativePlugin[key];
	}
}

